<?php  
if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

echo '<div class="panel panel-prebuilt-sections" style="display: none;"><ul class="prebuilt-sections-list"></ul></div>';